# Deprecated

This directory contains old scripts, data, models, log files, etc. that are **no longer maintained or used**. They are stored here rather than deleted to maintain a historical account of repository activity in an easily accessible and searchable location.  

Code in this directory is **unlikely to function as expected**, and should not be modified. If a script or dataset is to be revived or updated in some way, it should be moved from this directory to the appropriate location in the repository.


